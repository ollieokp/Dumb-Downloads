chmod -R 755 Dumb.app
./Dumb.app